//
//  BookAppointmentViewController.swift
//  Test
//
//  Created by TCP_CBE_Jr on 19/09/22.
//

import UIKit
import SwiftyJSON
import Kingfisher


class selectcarcell : UICollectionViewCell {
    
    @IBOutlet weak var carimg: UIImageView!
    
    @IBOutlet weak var carname: UILabel!
    
    @IBOutlet weak var carmodel: UILabel!
    
    @IBOutlet weak var tickimg: UIImageView!
    
}

class addcarcell : UICollectionViewCell {
    
    
    @IBOutlet weak var backimg: UIImageView!
    
    @IBOutlet weak var vehiclelbl: UILabel!
    
    
}


class BookAppointmentViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
 
    var carListArr = [CarModel]()
    var displayArr = [CarModel]()
    var selectedCar = CarModel()
    var passedCustomerVehicleSK = String()
    var vehicleTypeVal = "1"
    var selectedIndexPath = IndexPath()
    
    
    
    @IBOutlet weak var shopview: UIView!
    
    @IBOutlet weak var serviceview: UIView!
    
    @IBOutlet weak var dateview: UIView!
    
    @IBOutlet weak var hourview: UIView!
    
    @IBOutlet weak var applyview: UIView!
    
    @IBOutlet weak var readview: UIView!
    
    @IBOutlet weak var bookview: UIView!
    
    
    
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        bookview.layer.cornerRadius = 5
        
        shopview.layer.borderColor = UIColor.red.cgColor
        shopview.layer.borderWidth = 0.6
        shopview.layer.cornerRadius = 5
        
        serviceview.layer.borderColor = UIColor.red.cgColor
        serviceview.layer.borderWidth = 0.6
        serviceview.layer.cornerRadius = 5
        
        dateview.layer.borderColor = UIColor.red.cgColor
        dateview.layer.borderWidth = 0.6
        dateview.layer.cornerRadius = 5
        
        hourview.layer.borderColor = UIColor.red.cgColor
        hourview.layer.borderWidth = 0.6
        hourview.layer.cornerRadius = 5
        
        applyview.layer.borderColor = UIColor.red.cgColor
        applyview.layer.borderWidth = 0.6
        applyview.layer.cornerRadius = 5
        
        readview.layer.borderColor = UIColor.red.cgColor
        readview.layer.borderWidth = 0.6
        readview.layer.cornerRadius = 5
        
        
        
        
        displayArr = carListArr
        
        selectedIndexPath = IndexPath(item: 0, section: 0)
        getcars()
        
        
        
        
        
        
    }
    func getVehicleList(completionHandler: @escaping ([CarModel]) -> ()) {
        
        var carListArr = [CarModel]()
        
       
        
        let urlString = Const.BaseUrl+Const.kListVehicles
        let CustomerSK = getPrefName(key: "CustomerSK", value: "152289")
        let ShopSK = getPrefName(key: "ShopSK", value: "1908")
        let NeedLangaugeLabel = getPrefName(key: "NeedLangaugeLabel", value: "Y")
        
        let parameters = NSMutableDictionary()
        parameters.setObject(CustomerSK, forKey: "CustomerSK" as NSCopying )
        parameters.setObject(NeedLangaugeLabel, forKey: "NeedLangaugeLabel" as NSCopying)
        parameters.setObject(ShopSK, forKey: "ShopSK" as NSCopying)
        
        print(parameters)
        
        
        WebApiCallBack.requestApi(webUrl: urlString, paramData: parameters, methiod: Const.POST, completionHandler: { (responseObject, error) -> () in
            print(responseObject as Any)
            
            if responseObject != nil {
                
                let mresponse = JSON(responseObject!)
                
                if let carList = mresponse["CustVehiclesList"].array {
                    
                    for car in carList {
                        let object = CarModel()
                        object.AnnualInspectionDate = car["AnnualInspectionDate"].stringValue
                        object.Color = car["Color"].stringValue
                        object.CustomerName = car["CustomerName"].stringValue
                        object.CustomerSK = car["CustomerSK"].stringValue
                        object.CustomerVehicleSK = car["CustomerVehicleSK"].stringValue
                        object.EngineNo = car["EngineNo"].stringValue
                        object.LicencePlateNo = car["LicencePlateNo"].stringValue
                        object.Make = car["Make"].stringValue
                        object.ModelName = car["ModelName"].stringValue
                        object.ModelTrim = car["ModelTrim"].stringValue
                        object.ModelYear = car["ModelYear"].stringValue
                        object.NextServiceDate = car["NextServiceDate"].stringValue
                        object.VehiclePicture = car["VehiclePicture"].stringValue
                        object.VehicleSK = car["VehicleSK"].stringValue
                        object.VIN = car["VIN"].stringValue
                        object.showSpects = car["showSpects"].boolValue
                        object.BTGroupSK = car["BTGroupSK"].stringValue
                        object.BodyTypeSK = car["BodyTypeSK"].stringValue
                        object.BTGroupName = car["BTGroupName"].stringValue
                        object.BodyTypeName = car["BodyTypeName"].stringValue
                        carListArr.append(object)
                        
                        
                    }
                    
                    
                }
                
                let ShowOffer = mresponse["ShowOffer"].stringValue
                let ShowOdometer = mresponse["ShowOdometer"].stringValue
                let ShowServiceAdvisor = mresponse["ShowServiceAdvisor"].stringValue
                let ShowShopOption = mresponse["ShowShopOption"].stringValue
                updatePref(key: "ShowOffer", value: ShowOffer)
                updatePref(key: "ShowOdometer", value: ShowOdometer)
                updatePref(key: "ShowServiceAdvisor", value: ShowServiceAdvisor)
                updatePref(key: "ShowShopOption", value: ShowShopOption)
                
                completionHandler(carListArr)
                
            }
            
        })
    }
    
    

    func getcars() {
        
        if WebApiCallBack.isConnectedToNetwork() != true {
            showAlert(title: "Alert", message: "Please verify internet connectivity.", VC: BookAppointmentViewController())
        }else{
            
            
            getVehicleList(completionHandler: {(responseObject) -> () in
                
                print(responseObject)
                
                self.carListArr = responseObject
                self.displayArr = []
                for data in self.carListArr{
                    if self.vehicleTypeVal == data.BTGroupSK {
                        self.displayArr.append(data)
                        
                    }
                }
                
                self.collectionView.reloadData()
                
                
            })
            
            
        }
        
        
    }
    
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return displayArr.count + 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if indexPath.row == displayArr.count  {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell1", for: indexPath) as! addcarcell
            
            cell.layer.borderWidth = 1
            cell.layer.borderColor = UIColor.lightGray.cgColor
            cell.layer.cornerRadius = 4
            cell.clipsToBounds = true
            
            
            
            
            
            return cell
        }else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! selectcarcell
            
            cell.layer.borderWidth = 1
            cell.layer.borderColor = UIColor.lightGray.cgColor
            cell.layer.cornerRadius = 4
            cell.clipsToBounds = true
            
            let alllist = displayArr[indexPath.row]
            
            cell.carname.text = alllist.Make
            cell.carmodel.text = alllist.LicencePlateNo
            
            if alllist.VehiclePicture == "" {
//                cell.carimg.image = UIImage(named: "car.png")
                if alllist.BTGroupSK == "1" {
                    cell.carimg.image = UIImage(named: "vs_car_placeholder")
                }
            }else{
                
                let mCa = ImageCache(name: "my_cache")
                let url = URL(string:  alllist.VehiclePicture)
                cell.carimg.kf.indicatorType = .activity
                cell.carimg.kf.setImage(with: url, placeholder: nil, options: [.targetCache(mCa)])
                
            }
            
            
            cell.isSelected = true
            collectionView.selectItem(at: indexPath, animated: false, scrollPosition: [])
            
            if indexPath.row == selectedIndexPath.row {
                cell.tickimg.image = UIImage(named: "vs_tick.png")
                passedCustomerVehicleSK = "\(alllist.CustomerVehicleSK)"
                self.selectedCar.CustomerVehicleSK = passedCustomerVehicleSK
            }else {
                cell.tickimg.image = nil
            }
            
            return cell
        }
        
        
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        
        if indexPath.row == displayArr.count {
            
            let VC = self.storyboard?.instantiateViewController(withIdentifier: "AddVehicleViewController") as! AddVehicleViewController
//            VC.hidesBottomBarWhenPushed = true
//            VC.fromBookAppointmat = true
//            VC.vehicleTypeVal = vehicleTypeVal
//            VC.newVehicleDelegate = self
            self.navigationController!.pushViewController(VC, animated: true)
            
        }else {
            selectedIndexPath = indexPath
            self.collectionView.reloadData()
            self.selectedCar = displayArr[selectedIndexPath.row]
            
        }
        
        
    }
    
    
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    

}



