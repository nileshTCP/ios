//
//  BaseApp.swift
//  Test
//
//  Created by TCP_CBE_Jr on 19/09/22.
//

import Foundation



class appointmentModel: NSObject {
    
    var CustomerVehicleSK = String()
    var VehiclePicture = String()
    var LicencePlateNo = String()
    var NextServiceDate = String()
    var AppointmentDate = String()
    var AppointmentTime = String()
    var StatusModifierName = String()
    var PackagesArr = [packageModel]()
    
}

class packageModel: NSObject {

    var JobName = String()
    var JobSK = String()
    var JobType = String()
    
}

class CarModel: NSObject {
    var AnnualInspectionDate = String()
    var Color = String()
    var CustomerName = String()
    var CustomerSK = String()
    var CustomerVehicleSK = String()
    var EngineNo = String()
    var LicencePlateNo = String()
    var Make = String()
    var ModelName = String()
    var ModelTrim = String()
    var ModelYear = String()
    var NextServiceDate = String()
    var VIN = String()
    var VehiclePicture = String()
    var VehicleSK = String()
    var showSpects = Bool()
    var BTGroupName = String();
    var BTGroupSK = String();
    var BodyTypeName = String();
    var BodyTypeSK = String()
}

func getPrefName(key: String,value: String) ->String{
    let prefDefault = UserDefaults.standard
    if let keyVal: AnyObject = prefDefault.object(forKey: key as String) as AnyObject?{
        return keyVal as! String
    }else{
        return  value
    }
}


func updatePref(key: String,value: String){
    let prefDefault = UserDefaults.standard
    prefDefault.set(value, forKey: key)
}


