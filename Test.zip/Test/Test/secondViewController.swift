//
//  secondViewController.swift
//  Test
//
//  Created by TCP_CBE_Jr on 14/09/22.
//

import UIKit
let receivedData = NSNotification.Name("ReceiveData")



class secondViewController: UIViewController {
    

    
    @IBOutlet weak var lbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(onReceiveData(_:)), name: receivedData, object: nil)
            
    }
    
    
    @objc func onReceiveData(_ notification:Notification) {
        
        lbl.text = "notificationClick"
        lbl.textColor = .white
        self.view.backgroundColor = .systemBlue
       
    }
    
    
   

}



