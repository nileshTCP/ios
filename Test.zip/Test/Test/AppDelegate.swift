//
//  AppDelegate.swift
//  Test
//
//  Created by TCP_CBE_Jr on 14/09/22.
//

import UIKit
import Firebase
import FirebaseMessaging
import UserNotifications

@main
class AppDelegate: UIResponder, UIApplicationDelegate,MessagingDelegate {

    let gcmMessageIDKey = "gcm.message_id"
    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        FirebaseApp.configure()
        Messaging.messaging().isAutoInitEnabled = true
        // [START set_messaging_delegate]
        Messaging.messaging().delegate = self
        
   
        
        if #available(iOS 10.0, *) {
          // For iOS 10 display notification (sent via APNS)
          UNUserNotificationCenter.current().delegate = self

          let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
          UNUserNotificationCenter.current().requestAuthorization(
            options: authOptions,
            completionHandler: { _, _ in }
          )
        } else {
          let settings: UIUserNotificationSettings =
            UIUserNotificationSettings(types: [.alert, .badge, .sound], categories: nil)
          application.registerUserNotificationSettings(settings)
        }
        application.registerForRemoteNotifications()
        
        return true
    }
    
    // [START refresh_token]
    var FCMToken = String()
    func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String?) {
        print("Firebase registration token: \(fcmToken ?? "")")
        
        let dataDict:[String: String] = ["fcmtoken": "\(fcmToken ?? "")"]
        NotificationCenter.default.post(name: Notification.Name("FCMToken"), object: nil, userInfo: dataDict)
        FCMToken = fcmToken ?? ""


        UserDefaults.standard.synchronize() //MARK: FCM Notification
        // TODO: If necessary send token to application server.
        // Note: This callback is fired at each app startup and whenever a new token is generated.
        
    }
    
    

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    
    var orientationLock = UIInterfaceOrientationMask.all
    func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
        return self.orientationLock
    }
    
    struct AppUtility {
        static func lockOrientation(_ orientation: UIInterfaceOrientationMask) {
            if let delegate = UIApplication.shared.delegate as? AppDelegate {
                delegate.orientationLock = orientation
            }
        }
        
        static func lockOrientation(_ orientation: UIInterfaceOrientationMask, andRotateTo rotateOrientation:UIInterfaceOrientation) {
            self.lockOrientation(orientation)
            UIDevice.current.setValue(rotateOrientation.rawValue, forKey: "orientation")
        }
    }


}

extension AppDelegate: UNUserNotificationCenterDelegate {
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        Messaging.messaging().apnsToken = deviceToken
        let token = deviceToken.map { String(format: "%02.2hhx", $0) }.joined()
                print("InstanceIDtoken: \(token)")
        let defaults = UserDefaults.standard
        defaults.set(token, forKey: "FCMTokenKey")
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("Unable to register for remote notifications: \(error.localizedDescription)")
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        print("will gets called when app is in forground and we want to show banner")
        let userInfo = notification.request.content.userInfo
         Messaging.messaging().appDidReceiveMessage(userInfo)
         print(userInfo)
         // Change this to your preferred presentation option
        completionHandler([.alert,.sound,.badge])
    }

    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {

        let application = UIApplication.shared

        if(application.applicationState == .active){
            print("user tapped the notification bar when the app is in foreground")

        }

        if(application.applicationState == .inactive)
        {
            print("user tapped the notification bar when the app is in background")
        }

        if topViewController() is ViewController {
            let VC = topViewController().storyboard?.instantiateViewController(withIdentifier: "secondViewController") as! secondViewController
            topViewController().navigationController!.pushViewController(VC, animated: true)
        }else {
                        
            NotificationCenter.default.post(name: receivedData, object: nil)
            
            
        }


        completionHandler()
    }
    
    
    
//    func userNotificationCenter(_ center: UNUserNotificationCenter,
//                                        didReceive response: UNNotificationResponse,
//                                        withCompletionHandler completionHandler: @escaping () -> Void) {
//        let userInfo = response.notification.request.content.userInfo
//        // Print message ID.
//        if let messageID = userInfo[gcmMessageIDKey] {
//            print("Message ID: \(messageID)")
//        }
//
//        // Print full message.
//        print(userInfo)
//
//        if topViewController() is ViewController {
//            let VC = topViewController().storyboard?.instantiateViewController(withIdentifier: "secondViewController") as! secondViewController
//            topViewController().navigationController!.pushViewController(VC, animated: true)
//        }else {
//            let VC = topViewController().storyboard?.instantiateViewController(withIdentifier: "secondViewController") as! secondViewController
//            VC.fromNotification = true
//            topViewController().navigationController!.pushViewController(VC, animated: true)
//        }
//
//
//
//
//    }
    
    
    
    
    func topViewController() -> UIViewController {
        return topViewControllerWithRootViewController(rootViewController: UIApplication.shared.keyWindow!.rootViewController!)
    }
    
    func topViewControllerWithRootViewController(rootViewController: UIViewController) -> UIViewController {
      if (rootViewController is UINavigationController) {
            let navigationController: UINavigationController = (rootViewController as! UINavigationController)
            return topViewControllerWithRootViewController(rootViewController: navigationController.visibleViewController!)
        }else {
            return rootViewController
        }
    }

  
    
    func application(_ application: UIApplication,
    didReceiveRemoteNotification userInfo: [AnyHashable : Any],
       fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
      Messaging.messaging().appDidReceiveMessage(userInfo)
      completionHandler(.noData)
        // Print message ID.
          if let messageID = userInfo[gcmMessageIDKey] {
            print("Message ID: \(messageID)")
              print(userInfo)
          }
        // Print message ID.
        let dict = userInfo["body"] as! NSDictionary;
        let message = dict["title"];
        print(message!)
        if let messageID = userInfo[gcmMessageIDKey] {
            print("Message ID: \(messageID)")
        }
        print(userInfo)
        completionHandler(UIBackgroundFetchResult.newData)
    }
  
    func messaging(_ messaging: Messaging, didReceive remoteMessage: MessagingDelegate) {
        print("Received data message: \(remoteMessage.description)")
    }
   
}
