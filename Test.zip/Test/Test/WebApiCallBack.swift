
import UIKit
import Alamofire
import SwiftyJSON

import SystemConfiguration

let window = UIApplication.shared.keyWindow

let ReachabilityStatusChangedNotification = "ReachabilityStatusChangedNotification"

enum ReachabilityType: CustomStringConvertible {
    case WWAN
    case WiFi
    
    var description: String {
        switch self {
        case .WWAN: return "WWAN"
        case .WiFi: return "WiFi"
        }
    }
}

enum ReachabilityStatus: CustomStringConvertible  {
    case Offline
    case Online(ReachabilityType)
    case Unknown
    
    var description: String {
        switch self {
        case .Offline: return "Offline"
        case .Online(let type): return "Online (\(type))"
        case .Unknown: return "Unknown"
        }
    }
}

class WebApiCallBack:UIViewController{
    
    let count = 1
    class func connectionStatus() -> ReachabilityStatus {
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        guard let defaultRouteReachability = withUnsafePointer(to: &zeroAddress, {
            
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                
                SCNetworkReachabilityCreateWithAddress(nil, $0)
                
            }
            
        }) else {
            return .Unknown
        }
        
        var flags : SCNetworkReachabilityFlags = []
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags) {
            return .Unknown
        }
        
        return ReachabilityStatus(reachabilityFlags: flags)
    }
    
    
    class func monitorReachabilityChanges() {
        let host = "google.com"
        var context = SCNetworkReachabilityContext(version: 0, info: nil, retain: nil, release: nil, copyDescription: nil)
        let reachability = SCNetworkReachabilityCreateWithName(nil, host)!
        
        SCNetworkReachabilitySetCallback(reachability, { (_, flags, _) in
            let status = ReachabilityStatus(reachabilityFlags: flags)
            
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: ReachabilityStatusChangedNotification),
                                            object: nil)
            
        }, &context)
        SCNetworkReachabilityScheduleWithRunLoop(reachability, CFRunLoopGetMain(),context as! CFString)
    }
    class func isConnectedToNetwork() -> Bool {
        
        let status = connectionStatus()
        switch status {
        case .Unknown, .Offline:
            //            print("Not connected")
            return false
        case .Online(.WWAN):
            //            print("Connected via WWAN")
            return true
        case .Online(.WiFi):
            //            print("Connected via WiFi")
            return true
        }
        
    }
    
    class func requestApi(webUrl: String,paramData: NSObject, methiod: String, completionHandler: @escaping (NSDictionary?, NSError?) -> ()) {
        if (!isConnectedToNetwork()){
            
        }else{
            
            print(webUrl)
            
            if methiod == Const.POST {
                makePostCall(webUrl: webUrl, paramData: paramData,completionHandler: completionHandler)
            }else if methiod == Const.Get {
                makeGetCall(webUrl: webUrl, paramData: paramData,completionHandler: completionHandler)
            }else if methiod == Const.PUT {
                makePutCall(webUrl: webUrl, paramData: paramData,completionHandler: completionHandler)
            }else if methiod == Const.DELETE {
                let urlStr = webUrl + "&NeedLangaugeLabel=Y"
                makeDeleteCall(webUrl: urlStr, paramData: paramData,completionHandler: completionHandler)
                
            }
            
        }
    }
    
    class func makePostCall(webUrl: String, paramData: NSObject, completionHandler: @escaping (NSDictionary?, NSError?) -> ()) {
        let tokenVal = "sai"
        let authVal = "sai"
        
        let headersVal = [
            "Authorization": "Bearer "+(tokenVal as String),
            "auth": ""+(authVal as String)
        ]
        
        
        AF.request(webUrl, method: .post, parameters:  paramData as? [String : AnyObject], encoding: JSONEncoding.default)
            .responseJSON { response in
                //                print("First json \(response)")
                
                switch response.result {
                case .success(let value):
                    completionHandler(value as? NSDictionary, nil)
                case .failure(let error):
                    
                    //                 print("Failure with JSON: \(error)")
                    completionHandler(nil, error as NSError?)
                }
            }
    }
    
    class func makeGetCall(webUrl: String, paramData: NSObject, completionHandler: @escaping (NSDictionary?, NSError?) -> ()) {
        let tokenVal = "sai"
        let authVal = "sai"
        
        let headersVal = [
            "Authorization": "Bearer "+(tokenVal as String),
            "auth": ""+(authVal as String)
        ]
        
        
        AF.request(webUrl, method: .get, parameters:  nil, encoding: JSONEncoding.default)
            .responseJSON { response in
                //                print("First json \(response)")
                
                switch response.result {
                case .success(let value):
                    completionHandler(value as? NSDictionary, nil)
                case .failure(let error):
                    
                    //                 print("Failure with JSON: \(error)")
                    completionHandler(nil, error as NSError?)
                }
            }
    }
    
    class func makePutCall(webUrl: String, paramData: NSObject, completionHandler: @escaping (NSDictionary?, NSError?) -> ()) {
        let tokenVal = "sai"
        let authVal = "sai"
        
        let headersVal = [
            "Authorization": "Bearer "+(tokenVal as String),
            "auth": ""+(authVal as String)
        ]
        
        
        AF.request(webUrl, method: .put, parameters:  paramData as? [String : AnyObject], encoding: JSONEncoding.default)
            .responseJSON { response in
                //                print("First json \(response)")
                
                switch response.result {
                case .success(let value):
                    completionHandler(value as? NSDictionary, nil)
                case .failure(let error):
                    
                    //                 print("Failure with JSON: \(error)")
                    completionHandler(nil, error as NSError?)
                }
            }
    }
    
    class func makeDeleteCall(webUrl: String, paramData: NSObject, completionHandler: @escaping (NSDictionary?, NSError?) -> ()) {
        let tokenVal = "sai"
        let authVal = "sai"
        
        let headersVal = [
            "Authorization": "Bearer "+(tokenVal as String),
            "auth": ""+(authVal as String)
        ]
        
        
        AF.request(webUrl, method: .delete, parameters:  nil, encoding: JSONEncoding.default)
            .responseJSON { response in
                //                print("First json \(response)")
                
                switch response.result {
                case .success(let value):
                    completionHandler(value as? NSDictionary, nil)
                case .failure(let error):
                    
                    //                 print("Failure with JSON: \(error)")
                    completionHandler(nil, error as NSError?)
                }
            }
    }
    
    
}
extension ReachabilityStatus {
    init(reachabilityFlags flags: SCNetworkReachabilityFlags) {
        let connectionRequired = flags.contains(.connectionRequired)
        let isReachable = flags.contains(.reachable)
        let isWWAN = flags.contains(.isWWAN)
        
        if !connectionRequired && isReachable {
            if isWWAN {
                self = .Online(.WWAN)
            } else {
                self = .Online(.WiFi)
            }
        } else {
            self =  .Offline
        }
    }
}
