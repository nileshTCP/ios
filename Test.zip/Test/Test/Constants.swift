//
//  Constants.swift
//  Test
//
//  Created by TCP_CBE_Jr on 16/09/22.
//

import Foundation
import UIKit

class Const {
    
    static let POST = "post"
    static let Get = "Get"
    static let PUT = "Put"
    static let DELETE = "Delete"
    
    // API keys
    
    static let BaseUrl = "https://vvgarage.com/mobileapp/vvgdemo/"
    
    static let kListOfAppointments = "Appointments/AppointmentsOfACustomer"
 
    static let kListVehicles = "CustVehicles/GetCustVehiclesByCustomerSK"
    
    
}
