//
//  AddVehicleViewController.swift
//  Test
//
//  Created by TCP_CBE_Jr on 19/09/22.
//

import UIKit
import SwiftyJSON
import Kingfisher
import BarcodeScanner
import CropViewController
import Vision


class AddVehicleViewController: UIViewController,UITextFieldDelegate {
   
    
    @IBOutlet weak var vinview: UIView!
    
    @IBOutlet weak var plateview: UIView!
    
    @IBOutlet weak var yearview: UIView!
    
    @IBOutlet weak var makeview: UIView!
    
    @IBOutlet weak var modelview: UIView!
    
    @IBOutlet weak var trimview: UIView!
    
    @IBOutlet weak var bodyview: UIView!
    
    @IBOutlet weak var colorview: UIView!
    
    @IBOutlet weak var submitview: UIView!
    
    
    @IBOutlet weak var vintxt: UITextField!
    
    @IBOutlet weak var licensetxt: UITextField!
    
    @IBOutlet weak var yeartxt: UITextField!
    
    @IBOutlet weak var maketxt: UITextField!
    
    @IBOutlet weak var modeltxt: UITextField!
    
    @IBOutlet weak var trimtxt: UITextField!
    
    @IBOutlet weak var bodytypetxt: UITextField!
    
    @IBOutlet weak var colortxt: UITextField!
    
    @IBOutlet weak var imgUserPhoto: UIImageView!
    
    
    
    
    var vinImage = UIImage()
    var toGetVin = false
    var presentImage = UIImage()
    var imageFileName = "vs_cust_car_placeholder.png"

    override func viewDidLoad() {
        super.viewDidLoad()
        
        submitview.layer.cornerRadius = 5

        
        vinview.layer.cornerRadius = 5
        vinview.layer.borderColor = UIColor.red.cgColor
        vinview.layer.borderWidth = 0.6
        vinview.layer.cornerRadius = 5
        
        plateview.layer.cornerRadius = 5
        plateview.layer.borderColor = UIColor.red.cgColor
        plateview.layer.borderWidth = 0.6
        plateview.layer.cornerRadius = 5
        
        yearview.layer.cornerRadius = 5
        yearview.layer.borderColor = UIColor.red.cgColor
        yearview.layer.borderWidth = 0.6
        yearview.layer.cornerRadius = 5
        
        makeview.layer.cornerRadius = 5
        makeview.layer.borderColor = UIColor.red.cgColor
        makeview.layer.borderWidth = 0.6
        makeview.layer.cornerRadius = 5
        
        modelview.layer.cornerRadius = 5
        modelview.layer.borderColor = UIColor.red.cgColor
        modelview.layer.borderWidth = 0.6
        modelview.layer.cornerRadius = 5
        
        trimview.layer.cornerRadius = 5
        trimview.layer.borderColor = UIColor.red.cgColor
        trimview.layer.borderWidth = 0.6
        trimview.layer.cornerRadius = 5
        
        bodyview.layer.cornerRadius = 5
        bodyview.layer.borderColor = UIColor.red.cgColor
        bodyview.layer.borderWidth = 0.6
        bodyview.layer.cornerRadius = 5
        
        colorview.layer.cornerRadius = 5
        colorview.layer.borderColor = UIColor.red.cgColor
        colorview.layer.borderWidth = 0.6
        colorview.layer.cornerRadius = 5
        
        submitview.layer.cornerRadius = 5
        submitview.layer.borderColor = UIColor.red.cgColor
        submitview.layer.borderWidth = 0.6
        submitview.layer.cornerRadius = 5
        
        
       
        
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    
    @IBAction func camera(_ sender: Any) {
        vintxt.resignFirstResponder()
        toGetVin = true
        let actionSheet = UIAlertController(title: nil, message:"Select_your_choice",preferredStyle: .actionSheet)
        
        let BarCode = UIAlertAction(title:"BarCode", style: .default) { action in
            let viewController = self.makeBarcodeScannerViewController()
            //            AppDelegate.AppUtility.lockOrientation(.allButUpsideDown)
            viewController.headerViewController.titleLabel.text = "BarCode Scanner"
            viewController.headerViewController.closeButton.setTitle("Close", for: .normal)
            if #available(iOS 12.0, *) {
                if self.traitCollection.userInterfaceStyle == .dark {
                    viewController.headerViewController.titleLabel.textColor = UIColor.white
                    viewController.headerViewController.closeButton.setTitleColor(UIColor.white, for: .normal)
                }
            }
            self.present(viewController, animated: true, completion: nil)
        }
        actionSheet.addAction(BarCode)
        let cameraAction = UIAlertAction(title: "Camera", style: .default) { action in
            self.showCamera()
        }
        actionSheet.addAction(cameraAction)
        let albumAction = UIAlertAction(title: "Gallery", style: .default) { action in
            self.openPhotoAlbum()
        }
        actionSheet.addAction(albumAction)
        
        let cancelAction = UIAlertAction(title: "cancel", style: .cancel) { action in }
        actionSheet.addAction(cancelAction)
        
        present(actionSheet, animated: true, completion: nil)
        
        
    }
    
    private func makeBarcodeScannerViewController() -> BarcodeScannerViewController {
        let viewController = BarcodeScannerViewController()
        viewController.codeDelegate = self
        viewController.errorDelegate = self
        viewController.dismissalDelegate = self
        return viewController
    }
    
   
    
    

    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    

}


extension AddVehicleViewController: UINavigationControllerDelegate, UIImagePickerControllerDelegate, CropViewControllerDelegate {
    func showCamera() {
        let controller = UIImagePickerController()
        controller.delegate = self
        controller.sourceType = .camera
        present(controller, animated: true, completion: nil)
    }
    
    func openPhotoAlbum() {
        let controller = UIImagePickerController()
        controller.delegate = self
        controller.sourceType = .photoLibrary
        present(controller, animated: true, completion: nil)
    }
    // MARK: - UIImagePickerController delegate methods
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        guard let image = info[.originalImage] as? UIImage else {
            dismiss(animated: true, completion: nil)
            return
        }
        if toGetVin == true {
            vinImage = image
        }else {
            imgUserPhoto.image = image
        }
        
        dismiss(animated: true) { [unowned self] in
            self.openEditor(nil)
        }
    }
    
    
    @IBAction func openEditor(_ sender: UIBarButtonItem?) {
        if toGetVin == true {
            let controller = CropViewController(croppingStyle: .default, image: vinImage)
            controller.delegate = self
            
            let navController = UINavigationController(rootViewController: controller)
            present(navController, animated: true, completion: nil)
            
        }else {
            guard let image = imgUserPhoto.image else {
                return
            }
            let controller = CropViewController(croppingStyle: .default, image: image)
            controller.delegate = self
            
            let navController = UINavigationController(rootViewController: controller)
            present(navController, animated: true, completion: nil)
            
        }
        
    }
    
    // MARK: - CropView
    public func cropViewController(_ cropViewController: CropViewController, didCropToImage image: UIImage, withRect cropRect: CGRect, angle: Int) {
        //        self.croppedRect = cropRect
        //        self.croppedAngle = angle
        //        updateImageViewWithImage(image, fromCropViewController: cropViewController)
        
        cropViewController.dismiss(animated: true, completion: nil)
        if toGetVin == true {
            vinImage = image
            if #available(iOS 13.0, *) {
                print("getdata")
                getVinNumber()
            } else {
                // Fallback on earlier versions
            }
        }else {
            imgUserPhoto.image = image
//            updateEditButtonEnabled()
        }
        
    }
    
    func cropViewController(_ cropViewController: CropViewController, didFinishCancelled cancelled: Bool) {
        if toGetVin == true {
            toGetVin = false
        }else {
            self.imageFileName = "vs_cust_car_placeholder.png"
            imgUserPhoto.image = self.presentImage
//            updateEditButtonEnabled()
        }
        cropViewController.dismiss(animated: true, completion: nil)
        
    }
}

extension AddVehicleViewController: BarcodeScannerCodeDelegate {
    func scanner(_ controller: BarcodeScannerViewController, didCaptureCode code: String, type: String) {
        self.toGetVin = false
        print(code.replacingOccurrences(of: " ", with: "").trimmingCharacters(in: .whitespacesAndNewlines))
        vintxt.text = code.replacingOccurrences(of: " ", with: "").trimmingCharacters(in: .whitespacesAndNewlines)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            //            AppDelegate.AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
            controller.dismiss(animated: true, completion: nil)
        }
    }
    
}
extension AddVehicleViewController: BarcodeScannerErrorDelegate {
    func scanner(_ controller: BarcodeScannerViewController, didReceiveError error: Error) {
        self.toGetVin = false
        print(error)
    }
}

extension AddVehicleViewController: BarcodeScannerDismissalDelegate {
    func scannerDidDismiss(_ controller: BarcodeScannerViewController) {
        self.toGetVin = false
        AppDelegate.AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
        controller.dismiss(animated: true, completion: nil)
    }
}
extension AddVehicleViewController {
    
    @available(iOS 13.0, *)
    func getVinNumber()  {
        
        guard let cgImage = vinImage.cgImage else {
            
            fatalError("no image")
            
        }
        
        // Handler
        let handler = VNImageRequestHandler(cgImage: cgImage,options: [:])
        
        // Request
        let request = VNRecognizeTextRequest { [weak self] request, error in
            
            guard let observations = request.results as? [VNRecognizedTextObservation],
                  error == nil else {
                print("failed")
                return
            }
            
            let text = observations.compactMap({
                $0.topCandidates(1).first?.string
            }).joined(separator: ", ")
            print(text)
            DispatchQueue.main.async {
                self?.vintxt.text = text
                self?.imgUserPhoto.image = self?.vinImage
            }
        }
        
        //process request
        
        do{
            try handler.perform([request])
        }
        catch {
            print(error)
        }
        
     }
    
    
}
